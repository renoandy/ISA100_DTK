Starting with DTK1.16, the following steps need to be performed in order to initialize the DTK:

1.       Update �ss.ini� file with the appropriate DTK setup configuration;
2.       Inside �BIN� folder create an �iboot� file as a symbolic link to �iboot_manual� if the DTK setup not include an Iboot-DC device;
3.       Run �chmod_x_all_bash_recursively.sh� in order to configure appropriate right access for execution scripts;
